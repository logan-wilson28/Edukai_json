# JSON Chat Bot
A simple Python chat bot project simplifying my previous chat bot by adding a JSON file.

**NOTE:** All words that need to be recognised in the JSON file should be lowercased.
